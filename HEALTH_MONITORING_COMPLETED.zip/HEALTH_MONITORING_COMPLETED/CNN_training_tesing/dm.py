##from CNN_TESTING import get_result
##
##
##symptoms_inserted = ['itching','skin_rash','nodal_skin_eruptions','continuous_sneezing','shivering']
##result,acc,doctor_info,exercise_info,diet_info = get_result(symptoms_inserted)
##
##print('Result : ',result)
##print('Accuracy : ',acc)
##print('doctor_info : ',doctor_info)
##print('exercise_info : ',exercise_info)
##print('diet_info : ',diet_info)
##        
##
##


import os

path = os.getcwd() + '/toto'

print(path)
# /Users/mbp/Documents/my-project/python-snippets/notebook

print(type(path))
# <class 'str'>


